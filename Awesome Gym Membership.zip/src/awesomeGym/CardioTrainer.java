package awesomeGym;

public final class CardioTrainer extends GymStaff {
	
	//variables
	float numHolidays;
	
	//constructors
	CardioTrainer() {
		this.id = 0;
		this.name = "";
		this.hourlyRate = 0f;
	}//explicit default constructor - initialise variables
	
	CardioTrainer(int id, String name, float hourlyRate) {
		this.id = id;
		this.name = name;
		this.hourlyRate = hourlyRate;
	}//3 parameter constructor - int, string, float
	
	CardioTrainer(int id, String name, float hourlyRate, float numHolidays) {
		this(id, name, hourlyRate);
		numHolidays = numHolidays;
	}//4 parameter constructor - int, string, float, float

	//implement inherited abstract methods
	@Override
	void display() {
		System.out.println("ID: " + id);
		System.out.println("Name: " + name);
		System.out.println("No. of Holidays: " + numHolidays);
		calculateSalary();
		System.out.println("Salary: " + salary);
		System.out.println("Medical Cover: " + MEDICAL_COVER);
	}//display

	@Override
	void calculateSalary() {
		salary = hourlyRate * hoursWorked;
	}//calculate salary
	
	@Override
	void setHoursWorked(float hrsWorked) {
		this.hoursWorked = hrsWorked;
	}//setHoursWorked
	
	@Override
	public String toString() {
		return "ID: " + id + "\nName: " + name + "\nHourly Rate: " + hourlyRate + "\nSalary: " + salary;
	}//overridden toString() method
	
	public static void main(String[] args) {
		//setMedicalCover - static method
		CardioTrainer.setMedicalCover(1000);
		//create objects
		CardioTrainer enricoFermi = new CardioTrainer(006, "Enrico Fermi", 60f, 20);
		//output console
		enricoFermi.display();
		enricoFermi.toString();
		System.out.println(enricoFermi);
	}//main
}//final class
