package awesomeGym;

public abstract class GymStaff {
	//variables
	int id;
	String name;
	float hourlyRate, normalNumOfHours = 37.5f, salary;
	float hoursWorked = normalNumOfHours;
	static float MEDICAL_COVER = 500f;
	
	//abstract methods
	abstract void display();
	abstract void calculateSalary();
	abstract void setHoursWorked(float hoursWorked);
	
	//static methods
	static void setMedicalCover(float medicalCover) {
		MEDICAL_COVER = medicalCover;
	}
	
	public static void main(String[] args) {
		//output to the console
		//Calling both interface and class GymStaff statically to show medical cover changing
		FETACSportsCertification.setMedicalCover(3000f);
		System.out.println("Gym Staff Medical Cover: " + GymStaff.MEDICAL_COVER);
		GymStaff.setMedicalCover(550f);//showing change in setMedicalCover
		System.out.println("Interface Medical Cover: " + FETACSportsCertification.MEDICAL_COVER);
		System.out.println("Gym Staff Medical Cover: " + GymStaff.MEDICAL_COVER);
	}//main
}
