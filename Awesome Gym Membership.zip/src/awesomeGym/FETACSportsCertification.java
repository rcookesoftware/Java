package awesomeGym;

public interface FETACSportsCertification{
	
	//variables
	float EXAM_FEE = 800f;
	float DISCOUNT_FACTOR = 0.2f;
	float MEDICAL_COVER = 3000f;
	
	//static methods
	static void setMedicalCover(float medicalCover) {
		//MEDICAL_COVER = medicalCover; - unsure how to set medical cover within interface
		//as variables are final by default
		float MedicalCover = medicalCover;
	}//setMedicalCover
	
	//void abstract method
	abstract void payPartialExamFee();
	
	//default method
	default void displayPartialExamFee() {
	}//displayMedicalCover
}
