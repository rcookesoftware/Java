package awesomeGym;

public abstract class WeightLiftingTrainer extends GymStaff {
	
	//variables
	float numHolidays;
}//main
