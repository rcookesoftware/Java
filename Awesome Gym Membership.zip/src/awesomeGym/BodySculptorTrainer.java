package awesomeGym;

public class BodySculptorTrainer extends WeightLiftingTrainer {
	
	//variables
	float bonus;
	float overtime;
	
	//constructors
	BodySculptorTrainer() {
		id = 0;
		name = "";
		hourlyRate = 0f;
		numHolidays = 0f;
	}//explixit default constructor - initialise variables
	
	BodySculptorTrainer(String name, float hourlyRate, float bonus){
		this.name = name;
		this.hourlyRate = hourlyRate;
		this.bonus = 300f;
	}//3 param constructor - string, float, float
	
	BodySculptorTrainer(String name, float hourlyRate, float hoursWorked, float bonus){
		this(name, hourlyRate, bonus);
		this.hoursWorked = hoursWorked;
	}//4 param constructor - string, float, float, float
	
	//overloading methods
	void setBonus() {
		bonus = 0;
	}//set bonus
	
	void setBonus(float bonus) {
		this.bonus = bonus;
	}//overloaded setBonus method

	//implement inherited abstract methods
	@Override
	void display() {
		System.out.println("Name: " + name);
		calculateSalary();
		System.out.println("Salary: " + salary);
		System.out.println("Bonus: " + bonus + "\n");
	}//display

	@Override
	void calculateSalary() {
		if(hoursWorked > 37.5f) {
			overtime = hoursWorked - 37.5f;
			overtime = overtime * (hourlyRate * 1.5f);	
		}//if overtime has been done - calculate hours over 37.5 at 1.5 times the hourly rate
		salary = hourlyRate * 37.5f;
		salary += overtime;
	}//calculate salary

	@Override
	void setHoursWorked(float hoursWorked) {
		this.hoursWorked = hoursWorked;
	}//setHoursWorked
	
	//overriding equals() method to compare objects
	@Override
	public boolean equals(Object obj) {
		BodySculptorTrainer other = (BodySculptorTrainer)obj;
		if(other.name == other.name && other.hourlyRate == other.hourlyRate && other.bonus == other.bonus)
			return true;
		else return false;
	}//overridden equals()

	public static void main(String[] args) {
		//create objects
		BodySculptorTrainer janeGoodall = new BodySculptorTrainer("Jane Goodall", 140f, 47.5f, 300f);
		WeightLiftingTrainer mariaMitchell = new BodySculptorTrainer("Maria Mitchell", 250f, 5000f);//polymorphism
		BodySculptorTrainer myHusband = new BodySculptorTrainer("Smith", 150f, 100f);
		BodySculptorTrainer myWife = new BodySculptorTrainer("Smith", 150f, 100f);
		BodySculptorTrainer equalsTest = new BodySculptorTrainer();
		
		//output to console
		janeGoodall.display();
		mariaMitchell.display();
		System.out.println(myHusband.equals(myWife));//displaying use of overriden
		//equals() method - true
		System.out.println(myHusband.equals(equalsTest));//displaying use
		//equals() method - false
	}//main
}
