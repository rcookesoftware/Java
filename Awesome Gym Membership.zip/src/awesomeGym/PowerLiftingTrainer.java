package awesomeGym;

import java.security.Identity;
import competitionDetails.*;

public class PowerLiftingTrainer extends WeightLiftingTrainer implements FETACSportsCertification {
	
	//composition - creates competitor here
	Competitor competitor = new Competitor();
	
	//variables 
	float numHolidays;
	
	PowerLiftingTrainer(){
		id = 0;
		name = "";
		hourlyRate = 0f;
		numHolidays = 0f;
	}//explicit default constructor - initialise variables 
	
	PowerLiftingTrainer(int id, String name){
		this.id = id;
		this.name = name;
	}//2 parameters constructor - int, string
	
	PowerLiftingTrainer(int id, String name, float hourlyRate){
		this(id, name);
		this.hourlyRate = hourlyRate;
	}//3 parameters constructor - int, string, float
	
	PowerLiftingTrainer(int id, String name, float hourlyRate, float numHolidays){
		this(id, name, hourlyRate);
		this.numHolidays = numHolidays;
	}//4 parameters constructor - int, string, float, float
	
	//implement inherited abstract methods
	@Override
	void display() {
		System.out.println("ID: " + id);
		System.out.println("Name: " + name);
		System.out.println("No. of Holidays: " + numHolidays);
		calculateSalary();
		System.out.println("Salary: " + salary);
	}

	@Override
	void calculateSalary() {
		salary = hourlyRate * hoursWorked;
	}//calculate salary

	
	@Override
	void setHoursWorked(float hoursWorked) {
		this.hoursWorked += hoursWorked;
	}//setHoursWorked - add overtime to normalHoursWorked
	
	@Override
	public String toString() {
		return("ID: " + id + "\nName: " + name + "\nNo. of Holidays: " + numHolidays + "\n");
	}//overridden toString() method
	
	//implement interface methods
	@Override
	public void payPartialExamFee() {
		 float discount = EXAM_FEE - (DISCOUNT_FACTOR*EXAM_FEE);
		 System.out.println("Exam Fee is: " + discount);
	}//payPartialExamFee
	
	@Override
	public void displayPartialExamFee() {
		float discount = EXAM_FEE - (DISCOUNT_FACTOR*EXAM_FEE);
		System.out.println("Exam Fee is: " + discount);
	}//displayPartialExamFee
	
	public static void main(String[] args) {
		//create objects
		PowerLiftingTrainer edmondHalley = new PowerLiftingTrainer(7, "Edmond Halley", 150f);
		edmondHalley.setHoursWorked(15f);//add overtime
		
		PowerLiftingTrainer jenniferGreene = new PowerLiftingTrainer(8, "Jennifer Greene", 0f);
		
		//output to console 
		edmondHalley.display();
		System.out.println(edmondHalley);
		
		//demonstrating payPartialExamFee to pay discounted fee
		jenniferGreene.payPartialExamFee();
		
		//composition
		edmondHalley.competitor.calculateAllowableWeightLifted(100f);//calculate weight
		System.out.println(edmondHalley.competitor.displayAllowableWeightlifted());//display allowable weight
	}//main
}
