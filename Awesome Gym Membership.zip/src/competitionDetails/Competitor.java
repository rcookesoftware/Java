package competitionDetails;

public class Competitor {
	
	//variables
	float allowedWeights;
	
	public void calculateAllowableWeightLifted(float bodyWeight) {
		allowedWeights = bodyWeight * 2f;
	}//calculateAllowableWeightLifted
	
	public String displayAllowableWeightlifted() {
		return "Competitors allowable Weight Lifted is: " + allowedWeights;
	}//displayAllowableWeight
}//class
